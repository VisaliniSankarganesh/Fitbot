const API_KEY = 'AIzaSyBd6nwOU7-rbc1GuLMtUCRSHRsIknLv-Zw';
const API_URL = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash-latest:generateContent';

const chatMessages = document.getElementById('chat-messages');
const userInput = document.getElementById('user-input');
const sendButton = document.getElementById('send-button');

let localData = [];

fetch('file.json')
    .then(response => response.json())
    .then(data => localData = data)
    .catch(err => console.error('Failed to load file.json:', err));

function getSemanticMatch(userQuestion) {
    const threshold = 0.5;
    let bestMatch = null;
    let bestScore = 0;

    localData.forEach(item => {
        const score = similarity(item.question, userQuestion);
        if (score > bestScore) {
            bestScore = score;
            bestMatch = item;
        }
    });

    return bestScore >= threshold ? bestMatch.answer : null;
}

function similarity(a, b) {
    a = a.toLowerCase().split(/\s+/);
    b = b.toLowerCase().split(/\s+/);
    const common = a.filter(word => b.includes(word));
    return common.length / Math.max(a.length, b.length);
}

async function generateResponse(prompt) {
    const response = await fetch(`${API_URL}?key=${API_KEY}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            contents: [{ parts: [{ text: prompt }] }]
        })
    });

    if (!response.ok) throw new Error('Failed to generate response');
    const data = await response.json();
    return data.candidates[0].content.parts[0].text;
}

function cleanMarkdown(text) {
    return text.replace(/#{1,6}\s?/g, '')
               .replace(/\*\*/g, '')
               .replace(/\n{3,}/g, '\n\n')
               .trim();
}

function addMessage(message, isUser) {
    const messageElement = document.createElement('div');
    messageElement.classList.add('message', isUser ? 'user-message' : 'bot-message');

    const profileImage = document.createElement('img');
    profileImage.classList.add('profile-image');
    profileImage.src = isUser ? 'user.jpg' : 'bot.jpg';
    profileImage.alt = isUser ? 'User' : 'Bot';

    const messageContent = document.createElement('div');
    messageContent.classList.add('message-content');
    messageContent.textContent = message;

    messageElement.append(profileImage, messageContent);
    chatMessages.appendChild(messageElement);
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

async function handleUserInput() {
    const userMessage = userInput.value.trim();
    if (!userMessage) return;

    addMessage(userMessage, true);
    userInput.value = '';
    sendButton.disabled = userInput.disabled = true;

    try {
        // Check in file.json first
        let response = getSemanticMatch(userMessage);

        // If no match, query Gemini API
        if (!response) {
            response = await generateResponse(userMessage);
        }

        // Add the response to the chat
        addMessage(cleanMarkdown(response), false);
    } catch (error) {
        console.error('Error:', error);
        addMessage('Sorry, something went wrong.', false);
    } finally {
        sendButton.disabled = userInput.disabled = false;
        userInput.focus();
    }
}

sendButton.addEventListener('click', handleUserInput);

userInput.addEventListener('keypress', e => {
    if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        handleUserInput();
    }
});
